#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
python3 scripts/iniciar_local.py
